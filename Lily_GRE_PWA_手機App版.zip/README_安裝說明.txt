Lily GRE PWA
需部署到 HTTPS 網址後安裝。
iPhone/iPad：Safari 開啟網址 → 分享 → 加入主畫面。
Android：Chrome 開啟網址 → 安裝應用程式／加到主畫面。
答題、常錯字、⭐難記字等紀錄存在該網站的瀏覽器本機儲存空間，請定期使用網站內的匯出功能備份。
